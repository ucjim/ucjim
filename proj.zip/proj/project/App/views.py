from django.shortcuts import render
import datetime

#Create your views here.
def index(request):
    today = datetime.datetime.now().date()
    return render(request, 'index.html', {"today" : today})
def about(request):
    return render(request, 'about.html')
def contact(request):
    return render(request, 'contact.html')
def run(request):
    return render(request, 'run.html')
def com1_2560(request):
    return render(request, 'com1_2560.html')
def com2_2560(request):
    return render(request, 'com2_2560.html')
def com1_2561(request):
    return render(request, 'com1_2561.html')
def com2_2561(request):
    return render(request, 'com2_2561.html')
def com1_2562(request):
    return render(request, 'com1_2562.html')
def com2_2562(request):
    return render(request, 'com2_2562.html')
