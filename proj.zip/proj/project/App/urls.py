from django.urls import path
from . import views

urlpatterns = [
     path('', views.index, name='index'),
     path('about', views.about, name='about'),
     path('contact', views.contact, name='contact'),
     path('run', views.run, name='run'),
     path('com1_2560', views.com1_2560, name='com1_2560'),
     path('com2_2560', views.com2_2560, name='com2_2560'),
     path('com1_2561', views.com1_2561, name='com1_2561'),
     path('com2_2561', views.com2_2561, name='com2_2561'),
     path('com1_2562', views.com1_2562, name='com1_2562'),
     path('com2_2562', views.com2_2562, name='com2_2562')
]